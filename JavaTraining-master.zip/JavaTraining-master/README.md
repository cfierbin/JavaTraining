JavaTraining
============
Homeworks for Yakov Fain's Java Programming, 24-Hour Trainer
