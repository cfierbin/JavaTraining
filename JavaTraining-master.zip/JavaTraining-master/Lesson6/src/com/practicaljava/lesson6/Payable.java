package com.practicaljava.lesson6;

public interface Payable {
    int INCREASE_CAP = 20; 
	boolean increasePay(int percent);
}
