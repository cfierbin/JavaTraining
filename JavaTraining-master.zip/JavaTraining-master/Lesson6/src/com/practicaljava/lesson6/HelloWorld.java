package com.practicaljava.lesson6;

public class HelloWorld {

}
