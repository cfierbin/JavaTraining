
public class TestPolymorphicCalculator {

	public static void main(String[] args) {
		Calculator myCalculator = new GridBagLayoutCalculator();
		Calculator myOtherCalculator = new BoxLayoutCalculator();

	}

}
